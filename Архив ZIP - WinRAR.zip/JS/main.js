$(function)){
    $("offer-content a").clics  
}
DOMException
DOMException $(DOMException
    2)$(
        "ConvolverNode alert""
    )